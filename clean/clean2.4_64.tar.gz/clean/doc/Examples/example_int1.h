
int add (int v1,int v2); /* returns v1+v2 */
