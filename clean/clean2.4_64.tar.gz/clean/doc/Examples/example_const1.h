
#define ADD 10
#define SUB 20
#define AND 30
#define OR  40

#define ADD_OP '+'
#define SUB_OP '-'
#define AND_OP '&'
#define OR_OP  '|'

int compute (int operator,int arg1,int arg2);
