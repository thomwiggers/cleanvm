
#include "example_int1.h"

int add (int v1,int v2)
{
	return v1+v2;
}
