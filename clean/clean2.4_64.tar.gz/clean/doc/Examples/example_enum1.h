
enum {
	ADD,SUB,AND,OR
};

int compute (int operator,int arg1,int arg2);

